import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ProductListComponent } from '../product-list/product-list.component';
import { AppComponent } from '../app.component';
import { Product } from '../products';

@Component({
  selector: 'app-product-alerts',
  templateUrl: './product-alerts.component.html',
  styleUrl: './product-alerts.component.css',
})
export class ProductAlertsComponent {
  @Input() products: Product | undefined;
  @Output() notify = new EventEmitter();
  
}
